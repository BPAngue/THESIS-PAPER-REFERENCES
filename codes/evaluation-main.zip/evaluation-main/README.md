# General Boolean Function Suite Evaluation Repository

Contains the evaluation method for the cryptograhic benchmarks. 
