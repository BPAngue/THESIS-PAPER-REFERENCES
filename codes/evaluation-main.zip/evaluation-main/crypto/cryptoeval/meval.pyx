# %%cython --cplus
# distutils: language = c++
cimport cython
import numpy as np
cimport numpy as np
from libc.stdint cimport (uint8_t, uint32_t, uint64_t, int64_t)
from libc.stdlib cimport malloc, free

cdef extern from "./src/eval.h":
    ctypedef struct CgpParams:
        uint8_t inputs
        uint8_t outputs
        uint32_t rows
        uint32_t columns
        uint8_t node_inputs

cdef extern from "./src/crypto.cpp":
    int calc_crypto_properties(CgpParams *params, uint64_t *chromosome, double *output)

def get_crypto_properties(parameters, np.ndarray[np.uint64_t, ndim=1, mode='c'] chromosome):
    cdef double *res_arr
    cdef int num_props = 5
    cdef int err 
    cdef int i
    cdef CgpParams c_params

    c_params.inputs = parameters.inputs
    c_params.outputs = parameters.outputs
    c_params.rows = parameters.rows
    c_params.columns = parameters.columns
    c_params.node_inputs = parameters.node_inputs
 
    res_arr = <double *> malloc(num_props*sizeof(double))

    err = calc_crypto_properties(&c_params, <uint64_t *> np.PyArray_DATA(chromosome), res_arr)
    out = []
    for i in range(num_props):
        out.append(res_arr[i])
    free(res_arr)  
    if err != 0:
       raise Exception(f"Computation failed. Error code: {err}")
    return out

