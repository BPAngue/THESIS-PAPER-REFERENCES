import pyximport
pyximport.install()
# import os
# pyximport.install(inplace=True, build_in_temp=True,
#                  build_dir=os.path.join(os.path.dirname(__file__), 'tmp'))

import numpy as np
from .meval import get_crypto_properties

class Parameters:
    def __init__(self, inputs=4, outputs=1, rows=1, columns=10, node_inputs=2, function_set=None):
        self.inputs = inputs
        self.outputs = outputs
        self.rows = rows
        self.columns = columns
        self.node_inputs = node_inputs

    @property
    def nodes(self):
        return self.rows * self.columns

    @property
    def genes_per_node(self):
        return (1 + self.node_inputs)

    @property
    def node_genes(self):
        return self.rows * self.columns * (1 + self.node_inputs)

    @property
    def genes(self):
        return self.rows * self.columns * (1 + self.node_inputs) + self.outputs
