#ifndef EVAL_H
#define EVAL_H

#include <stdint.h>

typedef struct { 
    uint8_t inputs;
    uint8_t outputs;
    uint32_t rows;
    uint32_t columns;
    uint8_t node_inputs;

    void   *bdd_data;
    void   *tt_data;
} CgpParams;  

// Crypto functions
int calc_crypto_properties(CgpParams *params, uint64_t *chromosome, double *output);

#endif // EVAL_H
