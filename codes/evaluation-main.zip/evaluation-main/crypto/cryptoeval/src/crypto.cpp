#include <stdint.h>
#include <stdio.h>
#include "eval.h"
#include <iostream>

//#define DEBUG
#ifdef DEBUG
#include <iomanip>
#endif

//int calc_crypto_properties(CgpParams* params, uint64_t* chromosome, double* output); //declared in "eval.h"
static int simulate(CgpParams* params, uint64_t* chromosome, uint64_t* tt);  //turns chromosome into truth table
static int walsh_transform(CgpParams* params, uint64_t* tt, int64_t* ws);    //turns truth table into walsh spectrum
static int evaluate_crypto(CgpParams* params, int64_t* ws, double* output);  //turns walsh spectrum into a vector of cryptographic values
static int moebius_transform(CgpParams* params, uint64_t* tt, int64_t* anf); //turns truth table into algebraic normal form
static int evaluate_degree(CgpParams* params, int64_t* anf, double* output); //turns walsh spectrum into a degree (to be called after evaluate_crypto)
static unsigned int ncr(int n, int r);                                       //N-choose-R, used when caculating correlation immunity

int calc_crypto_properties(CgpParams* params, uint64_t* chromosome, double* output)
{

    //check input parameters
    if (output == NULL || params == NULL || chromosome == NULL)
    {
        std::cerr << "ERROR (calc_crypto_properties): missing arguments" << std::endl;
        return -1;
    }
    if (params->inputs > 32 || params->inputs < 1)
    {
        std::cerr << "ERROR (calc_crypto_properties): too many inputs (data types would overflow)" << std::endl;
        return -1;
    }
    if (params->outputs != 1)
    {
        std::cerr << "ERROR (calc_crypto_properties): too many outputs (vectorial boolean functions are not supported)" << std::endl;
        return -1;
    }
    if (params->node_inputs != 2)
    {
        std::cerr << "ERROR (calc_crypto_properties): too many/few node inputs (simulation of other than 2-input functions is not supported)" << std::endl;
        return -1;
    }

    unsigned int tt_length = 1;
    if (params->inputs > 6)
        tt_length = 1 << (params->inputs - 6);     //each input above the initial 6 doubles the size of TT
    unsigned int ws_length = 1 << params->inputs;  //wash spectrum uses integers, not booleans, and therefore can not be compressed


    //allocate truth table and walsh spectrum
    uint64_t* tt = new uint64_t[tt_length];
    int64_t* ws = new int64_t[ws_length];          //note that WS values CAN be negative
    int64_t* anf = new int64_t[ws_length];         //ANF values are boolean, but... for now we use less efficient system similar to ANF

#ifdef DEBUG
    //print parameters
    std::cout << "Parameters:" << std::endl;
    std::cout << "  inputs      = " << (uint64_t)params->inputs << std::endl;
    std::cout << "  outputs     = " << (uint64_t)params->outputs << std::endl;
    std::cout << "  rows        = " << (uint64_t)params->rows << std::endl;
    std::cout << "  columns     = " << (uint64_t)params->columns << std::endl;
    std::cout << "  node_inputs = " << (uint64_t)params->node_inputs << std::endl;
    std::cout << "  data        = " << (uint64_t)params->data << std::endl;
    std::cout << std::endl;

    std::cout << "Chromosome:" << std::endl;//just assume that there will always be exactly two function inputs
    unsigned int chromosome_length = (params->rows * params->columns * (params->node_inputs + 1)) + params->outputs;
    for (unsigned int i = 0; i < chromosome_length; i++)
    {
        if (i == chromosome_length - 1)
        {
            std::cout << "(" << chromosome[i] << ")" << std::endl;
        }
        else if ((i + 3) % 3 == 0)
        {
            std::cout << "(" << chromosome[i] << " ";
        }
        else if ((i + 2) % 3 == 0)
        {
            std::cout << chromosome[i] << " ";
        }
        else if ((i + 1) % 3 == 0)
        {
            std::cout << chromosome[i] << ") ";

            if ((i + 1) % 30 == 0)  //to increase read-ability
            {
                std::cout << std::endl;
            }
        }

    }
    std::cout << std::endl;
#endif

    if (simulate(params, chromosome, tt) < 0) //simulate circuit to obrain Truth Table (chromosome => TT)
        return -2;
    if (walsh_transform(params, tt, ws) < 0) //calculate Walsh Spectrum (TT => Walsh)
        return -3;
    if (evaluate_crypto(params, ws, output) < 0) //evaluate Cryptographic properties (Walsh => Crypto)
        return -4;
    if (moebius_transform(params, tt, anf) < 0) //calculate Walsh Spectrum (TT => Walsh)
        return -5;
    if (evaluate_degree(params, anf, output) < 0) //evaluate Cryptographic properties (Walsh => Crypto)
        return -6;

#ifdef DEBUG
    std::cout << "Output:" << std::endl;
    std::cout << "  nonlinearity   = " << output[0] << std::endl;
    std::cout << "  balancedness   = " << output[1] << std::endl;
    std::cout << "  corr immunity  = " << output[2] << std::endl;
    std::cout << "  hamming weight = " << output[3] << std::endl;
    //std::cout << "  UNUSED         = " << output[4] << std::endl;
    //std::cout << "  UNUSED         = " << output[5] << std::endl;
    //std::cout << "  UNUSED         = " << output[6] << std::endl;
    //std::cout << "  UNUSED         = " << output[7] << std::endl;
    //std::cout << "  UNUSED         = " << output[8] << std::endl;
    //std::cout << "  UNUSED         = " << output[9] << std::endl;
    std::cout << std::endl;
#endif

    //free memory
    delete[] tt;
    delete[] ws;
    delete[] anf;

    return 0;
}


//turns chromosome into truth table
static int simulate(CgpParams* params, uint64_t* chromosome, uint64_t* tt)
{


    unsigned int k = 0; //position of the start of the current active gene in the chromosome //used to simpily the notation during simulation
    //total legth of the chromosome
    unsigned int chromosome_length = (params->rows * params->columns * (params->node_inputs + 1)) + params->outputs;

    //calculate the legth f of the titable (number of simulation iterations)
    unsigned int tt_length = 1;
    if (params->inputs > 6)
        tt_length = 1 << (params->inputs - 6); //each input above the initial 6 doubles the size of the truth table

    //the number of values in the temporary values table (we calculate the value of each input and (active) node in the chormosome)
    unsigned int vals_length = params->inputs + params->rows * params->columns;
    uint64_t* vals = new uint64_t[vals_length]{};//the braces are there ot initilaize it with zeroes

    bool* active = new bool[vals_length]{};//create a second table of boolean values, to store whcih nodes are active and should be evluated

    //before the simulation starts, examine the chromosome to detemrine which nodes are active

    active[chromosome[chromosome_length - 1]] = true; //at first only the output node (determined by the very last gene) is active

    //go throug the list of all nodes in reverse order, and mark the inputs of active nodes as also being active
    for (unsigned int j = vals_length - 1 ; j >= params->inputs; j--)
    {
        if (active[j])//if the given node is marked as active
        {
            k = (j - params->inputs) * 3; //position of the start of the current active gene in the chromosome //used to simpily the notation

            switch (chromosome[k]) //based on the operator we decie whihc of the inputs to activate
            {
                case 0: case 15: //for contant functions, neither of the inputs is active
                    break;
                case 3: case 12: //only the first input is active
                    active[chromosome[k + 1]] = true;
                    break;
                case 5:	case 10: //only the second input is active
                    active[chromosome[k + 2]] = true;
                    break;
                default:         //in all other cases both inputs are active
                    active[chromosome[k + 1]] = true;
                    active[chromosome[k + 2]] = true;
                    break;
            }
        }
    }

#ifdef DEBUG
    std::cout << "Active Inputs and Nodes:" << std::endl;
    for (unsigned int i = 0; i < vals_length; i++)
    {
        if (active[i])
            std::cout << "X";       //active input or node
        else
            std::cout << "_";       //inactive inpur or node
        if ((i+1) == params->inputs)
            std::cout << " ";       //treshold between inputs and nodes
    }
    std::cout << std::endl << std::endl;
#endif

    //set the values of inputs


    //the first 6 inputs can be setbefore the main cycle, as their values remain constant
    if (params->inputs >= 1) vals[0] = 0xaaaaaaaaaaaaaaaa;
    if (params->inputs >= 2) vals[1] = 0xcccccccccccccccc;
    if (params->inputs >= 3) vals[2] = 0xf0f0f0f0f0f0f0f0;
    if (params->inputs >= 4) vals[3] = 0xff00ff00ff00ff00;
    if (params->inputs >= 5) vals[4] = 0xffff0000ffff0000;
    if (params->inputs >= 6) vals[5] = 0xffffffff00000000;

    //for every index in the truth table, do the following
    for (unsigned int i = 0; i < tt_length; i++)
    {
        //set the values of input variables
        //note that the smallest values are alway son the left (to make human interpretation of the results easier)

        for (unsigned int j = 6; j < params->inputs; j++)
        {
            ((i >> (j - 6)) & 1) ? vals[j] = 0xffffffffffffffff : vals[j] = 0x0000000000000000; //all other imputs are either all 0 or all 1, depending on the current iteration
        }

        //for all nodes, calculate their value based on their operation and inputs
        for (unsigned int j = params->inputs; j < vals_length; j++)
        {
            if (active[j])//if the given node is marked as active
            {
                k = (j - params->inputs) * 3; //position of the start of the current active gene in the chromosome //used to simpily the notation

                switch (chromosome[k]) //based on the operator we calculate one of 16 possible functions
                {
                    case  0: vals[j] = 0x0000000000000000                                     ; break; //'NULL', # null function, Y = 0
                    case  1: vals[j] = ~(vals[chromosome[k + 1]]  |   vals[chromosome[k + 2]]); break; //'NOR',  # NOR, Y = not(A | B)
                    case  2: vals[j] = (~vals[chromosome[k + 1]]) &   vals[chromosome[k + 2]] ; break; //'INHb', # Inhibition, B but not A, Y = not(A)&B
                    case  3: vals[j] =  ~vals[chromosome[k + 1]]                              ; break; //'NOTa', # NOT, Y = not(A)
                    case  4: vals[j] =   vals[chromosome[k + 1]]  & (~vals[chromosome[k + 2]]); break; //'INHa', # Inhibition, A but not B, Y = A & not(B)
                    case  5: vals[j] =                               ~vals[chromosome[k + 2]] ; break; //'NOTb', # NOT, Y = not(B)
                    case  6: vals[j] =   vals[chromosome[k + 1]]  ^   vals[chromosome[k + 2]] ; break; //'XOR',  # XOR, Y = A ^ B
                    case  7: vals[j] = ~(vals[chromosome[k + 1]]  &   vals[chromosome[k + 2]]); break; //'NAND', # NAND, Y = not(A & B)
                    case  8: vals[j] =   vals[chromosome[k + 1]]  &   vals[chromosome[k + 2]] ; break; //'AND',  # AND, Y = A & B
                    case  9: vals[j] = ~(vals[chromosome[k + 1]]  ^   vals[chromosome[k + 2]]); break; //'XNOR', # XNOR, Y = not(A ^ B)
                    case 10: vals[j] =                                vals[chromosome[k + 2]] ; break; //'BUFb', # transfer buffer, Y = B
                    case 11: vals[j] = (~vals[chromosome[k + 1]]) |   vals[chromosome[k + 2]] ; break; //'IMPb', # Implication, if A then B, Y = not(A) | B
                    case 12: vals[j] =   vals[chromosome[k + 1]]                              ; break; //'BUFa', # transfer buffer, Y = A
                    case 13: vals[j] =   vals[chromosome[k + 1]]  | (~vals[chromosome[k + 2]]); break; //'IMPa', # Implication, if B then A, Y = A | not(B)
                    case 14: vals[j] =   vals[chromosome[k + 1]]  |   vals[chromosome[k + 2]] ; break; //'OR',   # OR, Y = A | B
                    case 15: vals[j] = 0xffffffffffffffff                                     ; break; //'ID',   # identity, Y = 1
                }
            }
        }
        //copy the value of the output node to the truth table
        tt[i] = vals[chromosome[chromosome_length - 1]]; //index of the output node is always given by the last gene of the chromosome
    }

    //if the truth table shoudl have fewer than 64 bits, mask the upper parts of the array
    if (params->inputs == 1)
        tt[0] &= 0x0000000000000003;
    else if (params->inputs == 2)
        tt[0] &= 0x000000000000000f;
    else if (params->inputs == 3)
        tt[0] &= 0x00000000000000ff;
    else if (params->inputs == 4)
        tt[0] &= 0x000000000000ffff;
    else if (params->inputs == 5)
        tt[0] &= 0x00000000ffffffff;


#ifdef DEBUG
    std::cout << "Truth Table:" << std::endl;

    //if the table is shorter than the array, print only its bottom parts
    if      (params->inputs <= 2) std::cout << std::hex << std::setfill('0') << std::setw(1) << tt[0] << std::setfill(' ') << std::dec << std::endl;
    else if (params->inputs == 3) std::cout << std::hex << std::setfill('0') << std::setw(2) << tt[0] << std::setfill(' ') << std::dec << std::endl;
    else if (params->inputs == 4) std::cout << std::hex << std::setfill('0') << std::setw(4) << tt[0] << std::setfill(' ') << std::dec << std::endl;
    else if (params->inputs == 5) std::cout << std::hex << std::setfill('0') << std::setw(8) << tt[0] << std::setfill(' ') << std::dec << std::endl;
    else if (params->inputs >= 6) //regular sized arrays
    {
        for (int i = tt_length-1; i >= 0; i--)
        {
            std::cout << std::hex << std::setfill('0') << std::setw(16) << tt[i] << std::setfill(' ') << std::dec << std::endl;
        }
    }
    std::cout << std::endl;
#endif

    //free memory
    delete[] active;
    delete[] vals;

    return 0;
}

//turns truth table into walsh spectrum
static int walsh_transform(CgpParams* params, uint64_t* tt, int64_t* ws)
{
    //calculate the legth of the truth table and of the walsh spectrum
    unsigned int tt_length = 1;
    if (params->inputs > 6)
    {
        tt_length = 1 << (params->inputs - 6); //each input above the initial 6 doubles the size of the truth table
    }
    unsigned int ws_length = 1 << params->inputs; //wash spectrum use sintegers, not booleans, and therefore can not be compressed

    //use (unpack) truth table to initialize the array that will become the walsh spectrum
    if (ws_length < 64)
    {
        for (unsigned int j = 0; j < ws_length; j++)
        {
            ws[j] = -1 + 2 * ((tt[0] >> j) & 1);//unpacks "true" to "1" and "false" to "-1"
        }
    }
    else //(if ws_legth >= 64)
    {
        for (unsigned int i = 0; i < tt_length; i++)//
        {
            for (unsigned int j = 0; j < 64; j++)//
            {
                ws[i * 64 + j] = -1 + 2 * ((tt[i] >> j) & 1);//unpacks "true" to "1" and "false" to "-1"
            }
        }
    }

    //perform "fast walsh-hadamard transform" on the initilized array to gain the actual walsh spectrum
    for (unsigned int k = ws_length / 2; k > 0; k /= 2) // "k" is the distance between the relevant indexes of the current iteration, in total the transform performs "log(ws_legth)" iterations
    {
        for (unsigned int j = 0; j < ws_length; j += 2*k)  //"j" is the (start of) index of the current block of the tranform
        {
            for (unsigned int i = 0; i < k; i++) //"i" is the inded within the current block
            {
                ws[i+j]   = ws[i+j] +   ws[i+j+k];
                ws[i+j+k] = ws[i+j] - 2*ws[i+j+k];
            }
        }
    }


#ifdef DEBUG
    std::cout << "Walsh Spectum:" << std::endl;
    for (unsigned int j = 0; j < ws_length; j++)
    {
        std::cout << std::setw(2) << ws[j] << " ";
        if ((j + 1) % 64 == 0)
        {
            std::cout << std::endl;
        }
    }
    std::cout << std::endl;
#endif

    return 0;
}

//turns walsh spectrum into a vector of cryptographic values
static int evaluate_crypto(CgpParams* params, int64_t* ws, double* output)
{

    //initiliaze some variables
    unsigned int ws_length = 1 << params->inputs; //wash spectrum use sintegers, not booleans, and therefore can not be compressed

    double nonlinearity = -1.0;   //ranges from 0 (linear) to (2^(n-1)) - (2^((n/2)-1)) (bent)
    double balancedness = -1.0;   //ranges from 0 (contant 0 or constant 1) to 1 (balanced) (this value is always normalized)
    double corr_immunity = -1.0;  //ranges from 0 (non-immune) to n (constant 0 or constant 1) (non-integer should ALWAYS be rounded down)
    double hamming_weight = -1.0; //ranges from 0 (constant 0) to 2^n (constant 1)

    //hamming weight
    hamming_weight = (double) (ws_length + ws[0]) / 2 ;

    //balancendess
    balancedness = 1.0 - (abs(ws[0]) / (double)ws_length);

    //nonlinearity
    unsigned int linearity = 0;         //correlation to the nearest affine function
    for (unsigned int i = 0; i < ws_length; i++) //go though the whole WS and find the maximum absolute value
    {
        if (abs(ws[i]) > linearity)
        {
            linearity = (unsigned int) abs(ws[i]);
        }
    }
    nonlinearity = (ws_length - linearity) / 2.0;  //convert lineartiy ot nonlinearity (penalty for 1,-1 trick included)

    //DELETE END


    //correlation immunity
    unsigned int* corr_arr = new unsigned int[params->inputs + 1]{}; //array for counting of non-zero correlation (used for caculating the correlation immunity)

    //count the number all correlated affine functions (of each degree)
    for (unsigned int i = 0; i < ws_length; i++)     //for all indexes int he walsh spectrum
    {
        if (ws[i] != 0)                              //if the WS value of a given index is not zero, then TT corelates with the affine function
        {
            unsigned corr_idx = 0;
            for (unsigned int j = 0; j < params->inputs; j++) //determine the hamming weight (support) of the affine function's index
                corr_idx += ((i >> j) & 1);
            corr_arr[corr_idx]++;                    //increment the appropriate value in corr_array
        }
    }

    unsigned int corr_whole = 0;                     //for a function to have CI of degree "t", it must have zero correlation with all offine functions of degrees from "1" to "t"
    while((corr_whole < params->inputs) && corr_arr[corr_whole+1] == 0)
        corr_whole++;

    //DEBUG - testing of true falce corrleation immunity for resilient funcitons

    double corr_partial = 0.0;                       //how many of the next-level correlations are not zero
    if (corr_whole < params->inputs)
        corr_partial = 1.0 - (corr_arr[corr_whole + 1] / (double)ncr(params->inputs, corr_whole + 1)); //actual/maximum umbe rof non-zero indexes

    corr_immunity = corr_whole + corr_partial;

#ifdef DEBUG
    std::cout << "Array of Correlations:" << std::endl;
    for (int i = 0; i < (params->inputs + 1); i++)
    {
        std::cout << corr_arr[i] << " ";
    }
    std::cout << std::endl << std::endl;
#endif

    //write cryptographic properties to output
    output[0] = nonlinearity;
    output[1] = balancedness;
    output[2] = corr_immunity;
    output[3] = hamming_weight;
    //for (int i = 4; i < 10; i++)  //unused indexes
    //    output[i] = -1.0;

    //free memory
    delete[] corr_arr;

    return 0;
}


//turns truth table into algebraic normal form
static int moebius_transform(CgpParams* params, uint64_t* tt, int64_t* anf)
{

    //calculate the length of the truth table and of the walsh spectrum
    unsigned int tt_length = 1;
    if (params->inputs > 6)
    {
        tt_length = 1 << (params->inputs - 6); //each input above the initial 6 doubles the size of the truth table
    }
    unsigned int anf_length = 1 << params->inputs; //wash spectrum use sintegers, not booleans, and therefore can not be compressed


    //use (unpack) truth table to initialize the array that will become the algebraic normal form
    if (anf_length < 64)
    {
        for (unsigned int j = 0; j < anf_length; j++)
        {
            anf[j] = (tt[0] >> j) & 1;//unpacks "true" to "1" and "false" to "0"
        }
    }
    else //(if anf_legth >= 64)
    {
        for (unsigned int i = 0; i < tt_length; i++)//
        {
            for (unsigned int j = 0; j < 64; j++)//
            {
                anf[i * 64 + j] = (tt[i] >> j) & 1;//unpacks "true" to "1" and "false" to "0"
            }
        }
    }

    //Moebius transform
    for (unsigned int size = 2; size <= anf_length; size *= 2)
    {
        for (unsigned int index = 0; index < (anf_length / size); index++)
        {
            for (unsigned int position = size / 2; position < size; position++)
            {
                anf[index * size + position] ^= anf[index * size + position - size/2];
                
            }
        }
    }


#ifdef DEBUG
    std::cout << "Walsh Spectum:" << std::endl;
    for (unsigned int j = 0; j < anf_length; j++)
    {
        std::cout << anf[j];// << " ";
        if ((j + 1) % 64 == 0)
        {
            std::cout << std::endl;
        }
    }
    std::cout << std::endl;
#endif

    return 0;
}

//turns walsh spectrum into a degree (to be called after evaluate_crypto)
static int evaluate_degree(CgpParams* params, int64_t* anf, double* output) 
{

    unsigned int anf_length = 1 << params->inputs;            //algebraic normal form spectrum uses integers, not booleans, and therefore needs to be unpacked

    //algebraic degree
    unsigned int* deg_arr = new unsigned int[params->inputs + 1]{ }; //array for counting of non-zero correlation (used for caculating the correlation immunity)

    //count the number all correlated affine functions (of each degree)
    for (unsigned int i = 0; i < anf_length; i++)             //for all indexes in the algebraic normal form
    {
        if (anf[i] != 0)                                      //if the ANF value of a given index is not zero, then TT corelates with the affine function
        {
            unsigned deg_idx = 0;
            for (unsigned int j = 0; j < params->inputs; j++) //determine the Hamming weight (support) of the term's function's index
                deg_idx += ((i >> j) & 1);
            deg_arr[deg_idx]++;                               //increment the appropriate value in corr_array
        }
    }

#ifdef DEBUG
    std::cout << "Array of Degrees:" << std::endl;
    for (unsigned int i = 0; i < (params->inputs + 1); i++)
    {
        std::cout << deg_arr[i] << " ";
    }
    std::cout << std::endl << std::endl;
#endif

    int degree = -1;
    for (degree = params->inputs; deg_arr[degree] == 0 && degree > 0; degree--);
    output[4] = (double)degree;

    //free memory
    delete[] deg_arr;
    
    return 0;
}

unsigned int ncr(int n, int r)            //N-choose-R, used when caculating correlation immunity
{
    if (r == 0) return 1;                 //choose 0 => single options
    if (r > n / 2) return ncr(n, n - r);  //choose more than half => count how many options are NOT selected (it's faster)

    unsigned int result = 1;
    for (int k = 0; k < r; k++)           //number of the item being selected
        result = result * (n-k) / (k+1);  //multiply by the number of options, divide by the number of duplicities
    return result;
}

