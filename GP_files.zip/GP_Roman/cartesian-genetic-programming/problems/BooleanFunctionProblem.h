/*
 * ProblemBoolean.h
 *
 *  Created on: 08.11.2022
 *      Author: roman
 */

#ifndef PROBLEMS_BOOLEANFUNCTIONPROBLEM_H_
#define PROBLEMS_BOOLEANFUNCTIONPROBLEM_H_

#include <any>
#include <bitset>
#include <algorithm>
#include <cmath>

#include "../problems/BlackBoxProblem.h"

template<class E, class G, class F>
class BooleanFunctionProblem: public BlackBoxProblem<E, G, F> {
private:
	int num_bits;
	int num_outputs;
	int num_inputs;

	const int MAX_BITS = 32;

public:
	BooleanFunctionProblem(std::shared_ptr<Parameters> p_parameters,
			std::shared_ptr<Evaluator<E,G,F>> p_evalutor,
			std::shared_ptr<std::vector<std::vector<E>>> p_compressed_inputs,
			std::shared_ptr<std::vector<std::vector<E>>> p_compressed_outputs,
			int p_num_chunks);
	~BooleanFunctionProblem() = default;

	int get_bit(E n, E k);
	F evaluate(std::shared_ptr<std::vector<E>> outputs_real,
			std::shared_ptr<std::vector<E>> outputs_individual) override;
	F evaluate(E output_real, E output_individual) override;
	void evaluate_individual(std::shared_ptr<Individual<G,F>> individual)
			override;
};

template<class E, class G, class F>
BooleanFunctionProblem<E, G, F>::BooleanFunctionProblem(std::shared_ptr<Parameters> p_parameters,
		std::shared_ptr<Evaluator<E,G,F>> p_evaluator,
		std::shared_ptr<std::vector<std::vector<E>>> p_compressed_inputs,
		std::shared_ptr<std::vector<std::vector<E>>> p_compressed_outputs,
		int p_num_chunks) :
		BlackBoxProblem<E, G, F>(p_parameters, p_evaluator, p_num_chunks) {

	if (p_compressed_inputs == nullptr || p_compressed_outputs == nullptr) {
		throw std::invalid_argument(
				"Nullpointer exception in Boolean problem class!");
	}

	if (p_compressed_inputs->size() == 0 || p_compressed_outputs->size() == 0) {
		throw std::invalid_argument("Empty vector in Boolean problem class!");
	}


	num_inputs = this->parameters->get_num_inputs();
	num_outputs = this->parameters->get_num_outputs();
	num_bits = std::pow(2, num_inputs);

	if(num_bits > MAX_BITS) {
		num_bits = MAX_BITS;
	}

	E value;

	for (int i = 0; i < this->num_chunks; i++) {
		for (int j = 0; j < this->num_inputs; j++) {
			value = (*p_compressed_inputs)[i][j];
			this->inputs->at(i).push_back(value);
		}

		for (int j = 0; j < this->num_outputs; j++) {
			value = (*p_compressed_outputs)[i][j];
			this->outputs->at(i).push_back(value);
		}
	}
}

template<class E, class G, class F>
int BooleanFunctionProblem<E, G, F>::get_bit(E n, E k) {
	return (n >> k) & 1;
}

template<class E, class G, class F>
F BooleanFunctionProblem<E, G, F>::evaluate(
		std::shared_ptr<std::vector<E>> outputs_real,
		std::shared_ptr<std::vector<E>> outputs_individual) {
	int diff = 0;

	for (int i = 0; i < this->num_outputs; i++) {
		diff += this->evaluate(outputs_real->at(i), outputs_individual->at(i));
	}
	return diff;
}

template<class E, class G, class F>
F BooleanFunctionProblem<E, G, F>::evaluate(E output_real, E output_individual) {
	int diff = 0;

	E compare = output_individual ^ output_real;

	// Calculate bit error
	for (int j = 0; j < num_bits; j++) {
		E temp = compare;
		diff = diff + get_bit(temp, j);
	}
	return diff;
}

template<class E, class G, class F>
void BooleanFunctionProblem<E, G, F>::evaluate_individual(
		std::shared_ptr<Individual<G,F>> individual) {

	if(individual->is_evaluated()){
		return;
	}

	int diff = 0;

	std::shared_ptr<std::vector<E>> input_chunk;
	std::shared_ptr<std::vector<E>> output_chunk;
	std::shared_ptr<std::vector<E>> outputs_individual = std::make_shared<std::vector<E>>();

	this->evaluator->clear_maps();

	for (int i = 0; i < this->num_chunks; i++) {

		input_chunk = std::make_shared<std::vector<E>>(this->inputs->at(i));
		output_chunk = std::make_shared<std::vector<E>>(this->outputs->at(i));

		outputs_individual->clear();

		this->evaluator->evaluate(individual, input_chunk, outputs_individual);

		diff += this->evaluate(output_chunk, outputs_individual);
	}

	individual->set_fitness(diff);
	individual->set_evaluated(true);
}

#endif /* PROBLEMS_BOOLEANFUNCTIONPROBLEM_H_ */
