/*
 * Problem.h
 *
 *  Created on: 28.06.2021
 *      Author: roman
 */

#ifndef PROBLEMS_BLACKBOXPROBLEM_H_
#define PROBLEMS_BLACKBOXPROBLEM_H_

#include <stdexcept>
#include <memory>
#include <any>
#include "../parameters/Parameters.h"
#include "../evaluator/Evaluator.h"
#include "../representation/Individual.h"

template<class E, class G, class F>
class BlackBoxProblem {
protected:
	std::shared_ptr<Parameters> parameters;
	std::shared_ptr<Evaluator<E,G,F>> evaluator;

	std::shared_ptr<std::vector<std::vector<E>>> inputs;
	std::shared_ptr<std::vector<std::vector<E>>> outputs;

	std::shared_ptr<std::vector<E>> outputs_individual;

	int num_inputs;
	int num_outputs;
	int num_chunks = 1;
public:
	BlackBoxProblem(std::shared_ptr<Parameters> p_parameters,
			std::shared_ptr<Evaluator<E,G,F>> p_evaluator,
			int p_num_chunks);
	virtual F evaluate(std::shared_ptr<std::vector<E>> outputs_real,
			std::shared_ptr<std::vector<E>> outputs_individual) = 0;
	virtual F evaluate(E output_real, E output_individual) = 0;
	virtual void evaluate_individual(std::shared_ptr<Individual<G,F>> individual) = 0;
	virtual ~BlackBoxProblem() = default;
};

template<class E, class G, class F>
BlackBoxProblem<E, G, F>::BlackBoxProblem(std::shared_ptr<Parameters> p_parameters,
		std::shared_ptr<Evaluator<E,G,F>> p_evaluator, int p_num_chunks) {

	if (p_parameters != nullptr && p_evaluator != nullptr) {
		parameters = p_parameters;
		evaluator = p_evaluator;
	} else {
		throw std::invalid_argument(
				"Nullpointer exception in problem class!");
	}

	num_inputs = parameters->get_num_inputs();
	num_outputs = parameters->get_num_outputs();

	num_chunks = p_num_chunks;

	inputs = std::make_shared<std::vector<std::vector<E>>>(num_chunks);
	outputs = std::make_shared<std::vector<std::vector<E>>>(num_chunks);

	outputs_individual = std::make_shared<std::vector<E>>(num_outputs);

}


#endif /* PROBLEMS_BLACKBOXPROBLEM_H_ */
