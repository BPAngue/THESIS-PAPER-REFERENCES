################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../representation/integer/IntegerVectorIndividual.cpp \
../representation/integer/IntegerVectorSpecies.cpp 

CPP_DEPS += \
./representation/integer/IntegerVectorIndividual.d \
./representation/integer/IntegerVectorSpecies.d 

OBJS += \
./representation/integer/IntegerVectorIndividual.o \
./representation/integer/IntegerVectorSpecies.o 


# Each subdirectory must supply rules for building sources it contributes
representation/integer/%.o: ../representation/integer/%.cpp representation/integer/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	g++ -O3 -Wall -c -fmessage-length=0   -std=c++17 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-representation-2f-integer

clean-representation-2f-integer:
	-$(RM) ./representation/integer/IntegerVectorIndividual.d ./representation/integer/IntegerVectorIndividual.o ./representation/integer/IntegerVectorSpecies.d ./representation/integer/IntegerVectorSpecies.o

.PHONY: clean-representation-2f-integer

