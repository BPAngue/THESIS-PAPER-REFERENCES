################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../recombination/Recombination.cpp 

CPP_DEPS += \
./recombination/Recombination.d 

OBJS += \
./recombination/Recombination.o 


# Each subdirectory must supply rules for building sources it contributes
recombination/%.o: ../recombination/%.cpp recombination/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	g++ -O3 -Wall -c -fmessage-length=0   -std=c++17 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-recombination

clean-recombination:
	-$(RM) ./recombination/Recombination.d ./recombination/Recombination.o

.PHONY: clean-recombination

