/*
 * Selection.h
 *
 *  Created on: 11.01.2023
 *      Author: roman
 */

#ifndef SELECTION_SELECTION_H_
#define SELECTION_SELECTION_H_

class Selection {
public:
	Selection();
	virtual ~Selection();
};

#endif /* SELECTION_SELECTION_H_ */
