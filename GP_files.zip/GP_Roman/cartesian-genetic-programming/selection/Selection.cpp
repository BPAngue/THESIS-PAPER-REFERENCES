/*
 * Selection.cpp
 *
 *  Created on: 11.01.2023
 *      Author: roman
 */

#include "Selection.h"

Selection::Selection() {
	// TODO Auto-generated constructor stub

}

Selection::~Selection() {
	// TODO Auto-generated destructor stub
}

