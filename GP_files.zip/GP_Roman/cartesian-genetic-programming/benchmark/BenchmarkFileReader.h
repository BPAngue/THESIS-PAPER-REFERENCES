/*
 * BenchmarkReader.h
 *
 *  Created on: 11.11.2022
 *      Author: roman
 */

#ifndef BENCHMARKS_BOOL_BENCHMARKREADER_H_
#define BENCHMARKS_BOOL_BENCHMARKREADER_H_

#include <iostream>
#include <fstream>
#include <string>
#include <filesystem>
#include <exception>
#include <vector>
#include <any>
#include <memory>

template<class E>
class BenchmarkFileReader {
private:
	std::shared_ptr<std::vector<std::vector<E>>> compressed_inputs;
	std::shared_ptr<std::vector<std::vector<E>>> compressed_outputs;

	std::ifstream ifs;
	std::string line;

	int num_inputs;
	int num_outputs;
	int num_chunks;

public:
	BenchmarkFileReader();
	~BenchmarkFileReader() = default;
	void read_plu_file(std::string file_path);
	void print_compressed_data();

	std::shared_ptr<std::vector<std::vector<E>>> get_input_data() const;
	std::shared_ptr<std::vector<std::vector<E>>> get_output_data() const;
	int get_num_chunks() const;
	int get_num_inputs() const;
	int get_num_outputs() const;
};

template<class E>
BenchmarkFileReader<E>::BenchmarkFileReader() {
	compressed_inputs = std::make_shared<std::vector<std::vector<E>>>();
	compressed_outputs = std::make_shared<std::vector<std::vector<E>>>();
}

template<class E>
void BenchmarkFileReader<E>::print_compressed_data() {

	if (compressed_inputs.size() == 0) {
		throw std::runtime_error("No input data available!");
		return;
	}

	if (compressed_outputs.size() == 0) {
		throw std::runtime_error("No output data available!");
		return;
	}

	for (auto vec = compressed_inputs.begin(); vec != compressed_inputs.end();
			++vec) {
		for (auto it = vec->begin(); it != vec->end(); ++it) {
			std::cout << *it << " ";
		}
		std::cout << std::endl;
	}

	std::cout << std::endl;

	for (auto vec = compressed_outputs.begin(); vec != compressed_outputs.end();
			++vec) {
		for (auto it = vec->begin(); it != vec->end(); ++it) {
			std::cout << *it << " ";
		}
		std::cout << std::endl;
	}

}

template<class E>
void BenchmarkFileReader<E>::read_plu_file(std::string file_path) {

	if (file_path.size() == 0) {
		throw std::runtime_error("File path is an empty string!");
	}

	std::string extension = std::filesystem::path(file_path).extension();

	if (extension != ".plu") {
		throw std::runtime_error("Method only accepts PLU files!");
	}

	ifs.open(file_path, std::ifstream::in);

	char c;

	if (ifs.is_open()) {

		std::string str;
		E input;
		E output;

		ifs >> str >> num_inputs;
		ifs >> str >> num_outputs;
		ifs >> str >> num_chunks;

		std::vector<E> input_chunk;
		std::vector<E> output_chunk;

		for (int i = 0; i < num_chunks; i++) {

			for (int j = 0; j < num_inputs; j++) {
				ifs >> input;
				input_chunk.push_back(input);
			}

			// Inputs and outputs are seperated with whitespaces
			// Therefore, we skip this whitespace
			do {
				ifs.get(c);
			} while (ifs.peek() == ' ');

			for (int j = 0; j < num_outputs; j++) {
				ifs >> output;
				output_chunk.push_back(output);
			}

			compressed_inputs->push_back(input_chunk);
			compressed_outputs->push_back(output_chunk);

			input_chunk.clear();
			output_chunk.clear();
		}

		if (!ifs.good()) {
			throw std::runtime_error("Error while reading parameter file!");
		}

		ifs.close();

	} else {
		throw std::runtime_error("Error opening parameter file!");
	}

}

template<class E>
std::shared_ptr<std::vector<std::vector<E>>> BenchmarkFileReader<E>::get_input_data() const {
	return compressed_inputs;
}

template<class E>
std::shared_ptr<std::vector<std::vector<E>>> BenchmarkFileReader<E>::get_output_data() const {
	return compressed_outputs;
}

template<class E>
int BenchmarkFileReader<E>::get_num_chunks() const {
	return num_chunks;
}

template<class E>
int BenchmarkFileReader<E>::get_num_inputs() const {
	return num_inputs;
}

template<class E>
int BenchmarkFileReader<E>::get_num_outputs() const {
	return num_outputs;
}

#endif /* BENCHMARKS_BOOL_BENCHMARKREADER_H_ */
