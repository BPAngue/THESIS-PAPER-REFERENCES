/*
 * algorithm.h
 *
 *  Created on: 06.07.2021
 *      Author: roman
 */

#ifndef ALGORITHM_EVOLUTIONARYALGORITHM_H_
#define ALGORITHM_EVOLUTIONARYALGORITHM_H_

#include "../parameters/Parameters.h"
#include "../mutation/Mutation.h"
#include "../random/Random.h"
#include "../composite/EvolutionaryComposite.h"
#include "../representation/Individual.h"
#include "../problems/BlackBoxProblem.h"

#include <stdexcept>
#include <memory>
#include "../population/AbstractPopulation.h"

template<class E, class G, class F>
class EvolutionaryAlgorithm {
protected:
	long long max_fitness_evaluations;
	long long max_generations;
	int report_interval;
	int generation_number;
	int fitness_evaluations;

	bool report_during_job;
	bool is_ideal = false;

	F ideal_fitness;
	F best_fitness;

	std::shared_ptr<Random> random;
	std::shared_ptr<Parameters> parameters;

	std::shared_ptr<AbstractPopulation<G, F>> population;
	std::shared_ptr<Mutation<G,F>> mutation;
	std::shared_ptr<Species<G>> species;

	std::shared_ptr<Fitness<F>> fitness;
	std::shared_ptr<Functions<E>> functions;
	std::shared_ptr<BlackBoxProblem<E, G, F>> problem;

	std::shared_ptr<EvolutionaryComposite<E, G, F>> composite;
	std::vector<Individual<G, F>> offsprings;

	void report(int generation_number);
	void check_ideal(int generation_number);
	void evaluate();
	virtual void breed(int num_offspring) = 0;

public:
	EvolutionaryAlgorithm(
			std::shared_ptr<EvolutionaryComposite<E, G, F>> p_object);
	virtual ~EvolutionaryAlgorithm() = default;
	virtual std::pair<int, F> evolve()=0;
};

template<class E, class G, class F>
EvolutionaryAlgorithm<E, G, F>::EvolutionaryAlgorithm(
		std::shared_ptr<EvolutionaryComposite<E, G, F>> p_object) {

	if (p_object != nullptr) {
		this->composite = p_object;
	} else {
		throw std::invalid_argument(
				"Nullpointer exception in algorithm class!");
	}

	parameters = composite->get_parameters();
	random = composite->get_random();
	population = composite->get_population();
	mutation = composite->get_mutation();
	problem = composite->get_problem();
	fitness = composite->get_fitness();

	max_fitness_evaluations = parameters->get_max_fitness_evaluations();
	max_generations = parameters->get_max_generations();
	ideal_fitness = parameters->get_ideal_fitness();

	report_interval = parameters->get_report_interval();
	report_during_job = parameters->is_report_during_job();

	fitness_evaluations = 0;
	generation_number = 1;
}

template<class E, class G, class F>
void EvolutionaryAlgorithm<E, G, F>::evaluate() {

	std::shared_ptr<Individual<G, F>> individual;

	for (int i = 0; i < this->population->size(); i++) {
		individual = this->population->get_individual(i);
		this->problem->evaluate_individual(individual);
	}
}

template<class E, class G, class F>
void EvolutionaryAlgorithm<E, G, F>::report(int generation_number) {

	if (this->report_during_job) {
		if (generation_number % this->report_interval == 0) {
			std::cout << "Generation # " << this->generation_number
					<< " :: Best fitness: " << this->best_fitness << std::endl;
		}
	}
}

template<class E, class G, class F>
void EvolutionaryAlgorithm<E, G, F>::check_ideal(int generation_number) {
	this->is_ideal = this->fitness->is_ideal(this->best_fitness);

	if (this->is_ideal) {
		if (this->report_during_job) {
			std::cout << "Ideal fitness has been reached in generation # "
					<< this->generation_number << std::endl;
		}
	}
}

#endif /* ALGORITHM_EVOLUTIONARYALGORITHM_H_ */
