/*
 * Initializer.h
 *
 *  Created on: 12.01.2023
 *      Author: roman
 */

#ifndef INITIALIZER_INITIALIZER_H_
#define INITIALIZER_INITIALIZER_H_

#include "../random/Random.h"
#include "../parameters/Parameters.h"
#include "../representation/Individual.h"
#include "../representation/Species.h"
#include "../evaluator/Evaluator.h"
#include "../fitness/Fitness.h"
#include "../mutation/Mutation.h"
#include "../problems/BlackBoxProblem.h"
#include "../algorithm/EvolutionaryAlgorithm.h"
#include "../composite/EvolutionaryComposite.h"
#include "../population/StaticPopulation.h"

template<class E, class G, class F>
class Initializer {
protected:
	std::string benchmark_file;
	std::shared_ptr<Parameters> parameters;
	std::shared_ptr<EvolutionaryComposite<E, G, F>> composite;
	std::shared_ptr<Evaluator<E, G, F>> evaluator;
	std::shared_ptr<EvolutionaryAlgorithm<E, G, F>> algorithm;
	std::shared_ptr<BlackBoxProblem<E, G, F>> problem;
public:
	Initializer();
	Initializer(const std::string &p_benchmark_file);
	virtual ~Initializer() = default;
	const std::shared_ptr<EvolutionaryComposite<E, G, F> >& get_composite() const;
	const std::shared_ptr<EvolutionaryAlgorithm<E, G, F> >& get_algorithm() const;
	const std::shared_ptr<Parameters>& get_parameters() const;

	void init_comandline_parameters(int p_num_nodes, int p_num_inputs,
			int p_num_outputs, int p_num_functions, int p_max_arity,
			int p_num_parents, int p_num_offspring, float p_mutation_rate,
			long long p_max_fitness_evaluations, F p_ideal_fitness,
			int p_num_jobs, long long p_global_seed);

	void init_parfile_parameters(std::string parfile_path);
	void init_evolutionary_composite();
	virtual void init_problem() = 0;
	virtual void init_algorithm() = 0;
};

template<class E, class G, class F>
Initializer<E, G, F>::Initializer() {
	parameters = std::make_shared<Parameters>();
}

template<class E, class G, class F>
Initializer<E, G, F>::Initializer(const std::string &p_benchmark_file) :
		Initializer() {

	if (!p_benchmark_file.empty()) {
		this->benchmark_file = p_benchmark_file;
	} else {
		throw std::invalid_argument(
				"Empty file path string in initializer class!");
	}
}

template<class E, class G, class F>
void Initializer<E, G, F>::init_parfile_parameters(std::string parfile_path) {

	if (parfile_path.size() == 0) {
		throw std::runtime_error("File path is an empty string!");
	}

	std::string extension = std::filesystem::path(parfile_path).extension();

	if (extension != ".params") {
		throw std::runtime_error("Method only accepts param files!");
	}

	std::shared_ptr<std::vector<MUTATION_TYPE>> mutation_operators =
			parameters->get_mutation_operators();

	std::ifstream ifs;
	ifs.open(parfile_path, ios_base::in | ios_base::binary);

	if (ifs.is_open()) {

		std::string parameter;
		int value;

		while (ifs >> parameter >> value) {

			if (!ifs.good()) {
				throw std::runtime_error("Error while reading parameter file!");
			}

			bool state = (value == 1 ? true : false);

			if (parameter == "probabilistic_point_mutation" && state == true) {
				mutation_operators->push_back(
						parameters->PROBABILISTIC_POINT_MUTATION);
			} else if (parameter == "single_active_gene_mutation"
					&& state == true) {
				mutation_operators->push_back(
						parameters->SINGLE_ACTIVE_GENE_MUTATION);
			} else if (parameter == "mutation_type") {
				this->parameters->set_mutation_type(value);
			} else if (parameter == "print_parameters") {
				this->parameters->set_print_parameters(state);
			} else if (parameter == "evaluate_expression") {
				this->parameters->set_evaluate_expression(state);
			} else if (parameter == "minimizing_fitness") {
				this->parameters->set_minimizing_fitness(state);
			} else if (parameter == "report_during_job") {
				this->parameters->set_report_during_job(state);
			} else if (parameter == "report_after_job") {
				this->parameters->set_report_after_job(state);
			} else if (parameter == "report_simple") {
				this->parameters->set_report_simple(state);
			} else if (parameter == "report_interval") {
				this->parameters->set_report_interval(value);
			} else if (parameter == "simple_report_type") {
				this->parameters->set_simple_report_type(value);
			} else if (parameter == "generate_random_seed") {
				this->parameters->set_generate_random_seed(state);
			}
		}

	} else {
		throw std::runtime_error("Error opening PLU file!");
	}

	ifs.close();
}

template<class E, class G, class F>
void Initializer<E, G, F>::init_comandline_parameters(int p_num_nodes,
		int p_num_inputs, int p_num_outputs, int p_num_functions,
		int p_max_arity, int p_num_parents, int p_num_offspring,
		float p_mutation_rate, long long p_max_fitness_evaluations,
		F p_ideal_fitness, int p_num_jobs, long long p_global_seed) {

	this->parameters->set_num_function_nodes(p_num_nodes);
	this->parameters->set_num_inputs(p_num_inputs);
	this->parameters->set_num_outputs(p_num_outputs);
	this->parameters->set_num_functions(p_num_functions);
	this->parameters->set_max_arity(p_max_arity);
	this->parameters->set_num_offspring(p_num_offspring);
	this->parameters->set_mutation_rate(p_mutation_rate);
	this->parameters->set_max_fitness_evaluations(p_max_fitness_evaluations);
	this->parameters->set_ideal_fitness(p_ideal_fitness);
	this->parameters->set_num_jobs(p_num_jobs);
	this->parameters->set_genome_size();
	this->parameters->set_population_size(p_num_parents + p_num_offspring);
	this->parameters->set_global_seed(p_global_seed);
}

template<class E, class G, class F>
void Initializer<E, G, F>::init_evolutionary_composite() {
	this->composite = std::make_shared<EvolutionaryComposite<E, G, F>>(
			parameters);
	this->evaluator = composite->get_evaluator();
}

template<class E, class G, class F>
const std::shared_ptr<EvolutionaryComposite<E, G, F> >& Initializer<E, G, F>::get_composite() const {
	return composite;
}

template<class E, class G, class F>
const std::shared_ptr<EvolutionaryAlgorithm<E, G, F> >& Initializer<E, G, F>::get_algorithm() const {
	return algorithm;
}

template<class E, class G, class F>
const std::shared_ptr<Parameters>& Initializer<E, G, F>::get_parameters() const {
	return parameters;
}

#endif /* INITIALIZER_INITIALIZER_H_ */
