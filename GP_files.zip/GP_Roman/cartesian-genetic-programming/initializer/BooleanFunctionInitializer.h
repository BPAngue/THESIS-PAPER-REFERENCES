/*
 * BooleanFunctionInitializer.h
 *
 *  Created on: 13.01.2023
 *      Author: roman
 */

#ifndef INITIALIZER_BOOLEANFUNCTIONINITIALIZER_H_
#define INITIALIZER_BOOLEANFUNCTIONINITIALIZER_H_

#include <string>
#include "Initializer.h"

#include "../benchmark/BenchmarkFileReader.h"
#include "../algorithm/OnePlusLambda.h"
#include "../functions/BooleanFunctions.h"
#include "../problems/BooleanFunctionProblem.h"

template<class E, class G, class F>
class BooleanFunctionInitializer: public Initializer<E, G, F> {

private:
	std::shared_ptr<std::vector<std::vector<E>> > compressed_inputs;
	std::shared_ptr<std::vector<std::vector<E>> > compressed_outputs;

	int num_chunks;

public:
	BooleanFunctionInitializer(const std::string &p_benchmark_file);
	virtual ~BooleanFunctionInitializer() = default;
	void init_problem() override;
	void init_algorithm() override;
	void read_data();
};

template<class E, class G, class F>
BooleanFunctionInitializer<E, G, F>::BooleanFunctionInitializer(
		const std::string &p_benchmark_file) :
		Initializer<E, G, F>(p_benchmark_file) {
}

template<class E, class G, class F>
void BooleanFunctionInitializer<E, G, F>::read_data() {

	std::shared_ptr<BenchmarkFileReader<E>> bechmark_reader = std::make_shared<
			BenchmarkFileReader<E>>();

	bechmark_reader->read_plu_file(this->benchmark_file);

	this->compressed_inputs = bechmark_reader->get_input_data();
	this->compressed_outputs = bechmark_reader->get_output_data();

	int num_inputs = bechmark_reader->get_num_inputs();
	int num_outputs = bechmark_reader->get_num_outputs();

	this->parameters->set_num_inputs(num_inputs);
	this->parameters->set_num_outputs(num_outputs);
	this->num_chunks = bechmark_reader->get_num_chunks();
}

template<class E, class G, class F>
void BooleanFunctionInitializer<E, G, F>::init_problem() {

	std::shared_ptr<BooleanFunctionProblem<E, G, F>> problem = std::make_shared<
			BooleanFunctionProblem<E, G, F>>(this->parameters, this->evaluator,
			this->compressed_inputs, this->compressed_outputs, this->num_chunks);

	this->composite->set_problem(problem);
}

template<class E, class G, class F>
void BooleanFunctionInitializer<E, G, F>::init_algorithm() {
	this->algorithm = std::make_shared<OnePlusLambda<E, G, F>>(this->composite);
}


#endif /* INITIALIZER_BOOLEANFUNCTIONINITIALIZER_H_ */
