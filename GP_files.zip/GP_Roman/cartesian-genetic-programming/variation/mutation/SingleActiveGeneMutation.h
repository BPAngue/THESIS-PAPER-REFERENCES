/*
 * SingleActiveGeneMutation.h
 *
 *  Created on: 20.01.2023
 *      Author: roman
 */

#ifndef VARIATION_SINGLEACTIVEGENEMUTATION_H_
#define VARIATION_SINGLEACTIVEGENEMUTATION_H_

#include "../UnaryOperator.h"

template<class G, class F>
class SingleActiveGeneMutation: public UnaryOperator<G, F> {
public:
	SingleActiveGeneMutation(std::shared_ptr<Parameters> p_parameters,
			std::shared_ptr<Random> p_random,
			std::shared_ptr<Species<G>> p_species);

	virtual ~SingleActiveGeneMutation() = default;

	void variate(std::shared_ptr<Individual<G, F>> parent);
};

template <class G, class F>
SingleActiveGeneMutation<G, F>::SingleActiveGeneMutation(std::shared_ptr<Parameters> p_parameters,
		std::shared_ptr<Random> p_random,
		std::shared_ptr<Species<G>> p_species) : UnaryOperator<G, F>(p_parameters, p_random, p_species ) {
		this->name = "Single Active Gene Mutation";
}

template<class G, class F>
void SingleActiveGeneMutation<G, F>::variate(
		std::shared_ptr<Individual<G, F>> parent) {

	std::shared_ptr<std::vector<int>> active_nodes = parent->get_active_nodes();
	std::shared_ptr<G[]> genome =  parent-> get_genome();

	int num_active_nodes = active_nodes->size();

	if (num_active_nodes == 0) {
		return;
	}

	int min_gene_value = 0;

	int max_arity = this->parameters->get_max_arity();

	int rand_node_index = this->random->random_integer(0, num_active_nodes - 1);
	int rand_node_number = active_nodes->at(rand_node_index);
	int rand_gene_index = this->random->random_integer(0, max_arity);

	int mutation_pos = this->species->position_from_node_number(
			rand_node_number) + rand_gene_index;
	int max_gene_value = this->species->calc_max_gene(mutation_pos);

	genome[mutation_pos] = this->random->random_integer(min_gene_value,
			max_gene_value);

}

#endif /* VARIATION_SINGLEACTIVEGENEMUTATION_H_ */
