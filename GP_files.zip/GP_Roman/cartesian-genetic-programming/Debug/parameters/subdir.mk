################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../parameters/Parameters.cpp 

CPP_DEPS += \
./parameters/Parameters.d 

OBJS += \
./parameters/Parameters.o 


# Each subdirectory must supply rules for building sources it contributes
parameters/%.o: ../parameters/%.cpp parameters/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross G++ Compiler'
	g++ -O3 -g3 -Wall -c -fmessage-length=0   -std=c++17 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-parameters

clean-parameters:
	-$(RM) ./parameters/Parameters.d ./parameters/Parameters.o

.PHONY: clean-parameters

