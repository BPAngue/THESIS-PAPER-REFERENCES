/*
 * Evolver.h
 *
 *  Created on: 14.01.2023
 *      Author: roman
 */

#ifndef EVOLVER_EVOLVER_H_
#define EVOLVER_EVOLVER_H_

#include "../initializer/BooleanFunctionInitializer.h"
#include "../algorithm/EvolutionaryAlgorithm.h"
#include "../random/Random.h"

template<class E, class G, class F>
class Evolver {
private:

	int num_jobs;

	bool report_after_job;
	bool report_simple;
	EVAL_METHOD simple_report_type;

	std::shared_ptr<Initializer<E, G, F>> initializer;
	std::shared_ptr<Parameters> parameters;
	std::shared_ptr<Random> random;
	std::shared_ptr<EvolutionaryComposite<E, G, F>> composite;

	std::shared_ptr<EvolutionaryAlgorithm<E, G, F>> algorithm;
	std::shared_ptr<AbstractPopulation<G, F>> population;

public:
	Evolver(std::shared_ptr<Initializer<E, G, F>> p_initializer);
	virtual ~Evolver() = default;
	void run();
};

template<class E, class G, class F>
Evolver<E, G, F>::Evolver(std::shared_ptr<Initializer<E, G, F>> p_initializer) {

	if (p_initializer != nullptr) {
		initializer = p_initializer;
		composite = p_initializer->get_composite();
		random = composite->get_random();
	} else {
		throw std::invalid_argument("Nullpointer exception in evolver class!");
	}

	parameters = composite->get_parameters();
	num_jobs = parameters->get_num_jobs();
	report_after_job = this->parameters->is_report_after_job();
	report_simple = this->parameters->is_report_simple();

	if(report_simple) {
		simple_report_type = this->parameters->get_simple_report_type();
	}

}

template<class E, class G, class F>
void Evolver<E, G, F>::run() {

	if(this->parameters->is_print_parameters()) {
			this->parameters->print();
	}

	this->population = this->composite->get_population();
	this->algorithm = this->initializer->get_algorithm();

	std::pair<int, F> result;

	for (int job = 1; job <= this->num_jobs; job++) {

		if (job > 1) {
			this->population->reset();
		}

		result = algorithm->evolve();

		if (report_after_job) {
			if (report_simple) {
				if (simple_report_type
						== this->parameters->FITNESS_EVALUATIONS_TO_TERMINATION) {
					std::cout << result.first << std::endl;
				} else {
					std::cout << result.second << std::endl;
				}
			} else {
				std::cout << "Job # " << job << " :: Fitness Evaluations: "
						<< result.first << " :: Best Fitness: " << result.second
						<< std::endl;
			}
		}

		if (this->parameters->is_generate_random_seed()) {
				this->random->set_random_seed();
		}
	}
}

#endif /* EVOLVER_EVOLVER_H_ */
