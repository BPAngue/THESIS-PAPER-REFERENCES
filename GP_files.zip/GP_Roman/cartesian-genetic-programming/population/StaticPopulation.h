/*
 * Population.h
 *
 *  Created on: 17.07.2021
 *      Author: roman
 */

#ifndef POPULATION_STATICPOPULATION_H_
#define POPULATION_STATICPOPULATION_H_

#include <stdexcept>
#include <vector>
#include <memory>
#include <cassert>

#include "../population/AbstractPopulation.h"
#include "../parameters/Parameters.h"
#include "../representation/Individual.h"
#include "../random/Random.h"

template<class G, class F>
class StaticPopulation: public AbstractPopulation<G, F> {
private:
	std::shared_ptr<std::shared_ptr<Individual<G, F>>[]> individuals;

	void init() override;

public:
	StaticPopulation(std::shared_ptr<Random> p_random,
			std::shared_ptr<Parameters> p_parameters);
	virtual ~StaticPopulation() = default;
	void print() override;
	void reset() override;
	int size() override;
	std::shared_ptr<Individual<G, F> > get_individual(int index) const override;
	void set_individual(std::shared_ptr<Individual<G, F> > individual,
			int index) override;
};

template<class G, class F>
StaticPopulation<G, F>::StaticPopulation(std::shared_ptr<Random> p_random,
		std::shared_ptr<Parameters> p_parameters) :
		AbstractPopulation<G, F>(p_random, p_parameters) {

	//individuals = std::make_shared<std::shared_ptr<Individual<G, F>>[]>(
	//		this->population_size);

	std::shared_ptr<std::shared_ptr<Individual<G, F>>[]> shared_population_ptr(
			new std::shared_ptr<Individual<G, F>>[this->population_size]());

	this->individuals = shared_population_ptr;

	this->init();
}

template<class G, class F>
void StaticPopulation<G, F>::reset() {
	for (int i = 0; i < this->population_size; i++) {
		std::shared_ptr<Individual<G, F>> ind = this->get_individual(i);
		ind->reset();
	}
}

template<class G, class F>
void StaticPopulation<G, F>::init() {
	for (int i = 0; i < this->population_size; i++) {
		std::shared_ptr<Individual<G, F>> ind = std::make_shared<
				Individual<G, F>>(this->random, this->parameters);
		this->individuals[i] = ind;
	}
}

template<class G, class F>
void StaticPopulation<G, F>::print() {
	for (int i = 0; i < this->population_size; i++) {

		std::string genome_str = individuals[i]->to_string();
		std::cout << "Individual #" << i << " :: Fitness: "
				<< individuals[i]->get_fitness() << " :: Genome: " << genome_str
				<< std::endl;
	}
}

template<class G, class F>
int StaticPopulation<G, F>::size() {
	return this->population_size;
}

template<class G, class F>
std::shared_ptr<Individual<G, F> > StaticPopulation<G, F>::get_individual(
		int index) const {
	assert(index >= 0 && index < this->population_size);
	return individuals[index];
}

template<class G, class F>
void StaticPopulation<G, F>::set_individual(
		std::shared_ptr<Individual<G, F> > individual, int index) {
	assert(index >= 0 && index < this->population_size);
	this->individuals[index] = individual;
}

#endif /* POPULATION_STATICPOPULATION_H_ */
