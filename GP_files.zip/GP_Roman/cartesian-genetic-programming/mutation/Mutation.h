/*
 * Mutation.h
 *
 *  Created on: 08.07.2021
 *      Author: roman
 */

#ifndef MUTATION_H_
#define MUTATION_H_

#include "../parameters/Parameters.h"
#include "../random/Random.h"
#include "../representation/Species.h"

#include <stdexcept>
#include <iostream>
#include <memory>

template<class G, class F>
class Mutation {
private:
	std::shared_ptr<Parameters> parameters;
	std::shared_ptr<Random> random;
	std::shared_ptr<Species<G>> species;
	float mutation_rate;
	MUTATION_TYPE mutation_type;
public:
	Mutation(std::shared_ptr<Parameters> p_parameters,
			std::shared_ptr<Random> p_random,
			std::shared_ptr<Species<G>> p_species);
	virtual ~Mutation() = default;
	void mutate(std::shared_ptr<Individual<G, F>> parent);
	void point_mutation(std::shared_ptr<G[]> genome);
	void sag_mutation(std::shared_ptr<G[]> genome,
			std::shared_ptr<std::vector<int>> active_nodes);
};

template<class G, class F>
Mutation<G, F>::Mutation(std::shared_ptr<Parameters> p_parameters,
		std::shared_ptr<Random> p_random,
		std::shared_ptr<Species<G>> p_species) {

	if (p_parameters != nullptr) {
		this->parameters = p_parameters;
		this->mutation_rate = p_parameters->get_mutation_rate();
		this->mutation_type = p_parameters->get_mutation_type();
	} else {
		throw std::invalid_argument("p_parameters is null in mutation class!");
	}

	if (p_random != nullptr) {
		this->random = p_random;
	} else {
		throw std::invalid_argument("p_random is null in mutation class!");
	}

	if (p_species != nullptr) {
		this->species = p_species;
	} else {
		throw std::invalid_argument("p_species is null in mutation class!");
	}
}

template<class G, class F>
void Mutation<G, F>::mutate(std::shared_ptr<Individual<G, F>> parent) {

	std::shared_ptr<G[]> genome = parent->get_genome();
	MUTATION_TYPE mutation_type = this->parameters->get_mutation_type();

	if( mutation_type == parameters->PROBABILISTIC_POINT_MUTATION) {
		this->point_mutation(genome);
	}
	else if(mutation_type == parameters->SINGLE_ACTIVE_GENE_MUTATION) {
		std::shared_ptr<std::vector<int>> active_nodes = parent->get_active_nodes();
		this->sag_mutation(genome,active_nodes);
	}
}

template<class G, class F>
void Mutation<G, F>::point_mutation(std::shared_ptr<G[]> genome) {

	int genome_size = this->parameters->get_genome_size();
	int max_gene_value;
	int min_gene_value = 0;

	int num_mutations = this->mutation_rate * genome_size;
	int random_pos;

	for (int i = 0; i < num_mutations; i++) {

		random_pos = this->random->random_integer(0, genome_size - 1);

		if (this->species->is_real_valued()) {
			genome[random_pos] = this->random->random_float(0.0, 1.0);
		} else {
			max_gene_value = this->species->calc_max_gene(random_pos);
			genome[random_pos] = this->random->random_integer(min_gene_value,
					max_gene_value);
		}

	}
}

template<class G, class F>
void Mutation<G, F>::sag_mutation(std::shared_ptr<G[]> genome,
		std::shared_ptr<std::vector<int>> active_nodes) {

	int num_active_nodes = active_nodes->size();

	if (num_active_nodes == 0) {
		return;
	}

	int min_gene_value = 0;

	int max_arity = this->parameters->get_max_arity();

	int rand_node_index = this->random->random_integer(0, num_active_nodes - 1);
	int rand_node_number = active_nodes->at(rand_node_index);
	int rand_gene_index = this->random->random_integer(0, max_arity);

	int mutation_pos = this->species->position_from_node_number(
			rand_node_number) + rand_gene_index;
	int max_gene_value = this->species->calc_max_gene(mutation_pos);

	genome[mutation_pos] = this->random->random_integer(min_gene_value,
			max_gene_value);
}

#endif /* MUTATION_H_ */
