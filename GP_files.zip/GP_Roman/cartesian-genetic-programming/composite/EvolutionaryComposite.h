/*
 * EvolutionaryObject.h
 *
 *  Created on: 11.01.2023
 *      Author: roman
 */

#ifndef COMPOSITE_EVOLUTIONARYCOMPOSITE_H_
#define COMPOSITE_EVOLUTIONARYCOMPOSITE_H_

#include <memory>

#include "../benchmark/BenchmarkFileReader.h"
#include "../random/Random.h"

#include "../parameters/Parameters.h"

#include "../representation/Individual.h"
#include "../representation/Species.h"

#include "../population/StaticPopulation.h"
#include "../functions/BooleanFunctions.h"
#include "../evaluator/Evaluator.h"
#include "../fitness/Fitness.h"
#include "../mutation/Mutation.h"
#include "../mutation/MutationPipeline.h"
#include "../problems/BlackBoxProblem.h"

template<class E, class G, class F>
class EvolutionaryComposite {
private:
	void init();

	std::shared_ptr<Random> random;
	std::shared_ptr<Parameters> parameters;

	std::shared_ptr<StaticPopulation<G, F>> population;
	std::shared_ptr<Mutation<G,F>> mutation;
	std::shared_ptr<MutationPipeline<G, F>> mutation_pipeline;
	std::shared_ptr<Species<G>> species;

	std::shared_ptr<Fitness<F>> fitness;
	std::shared_ptr<Functions<E>> functions;
	std::shared_ptr<BlackBoxProblem<E, G, F>> problem;

	std::shared_ptr<Evaluator<E, G, F>> evaluator;

public:
	EvolutionaryComposite(std::shared_ptr<Parameters> p_parameters);
	virtual ~EvolutionaryComposite() = default;
	const std::shared_ptr<Evaluator<E, G, F> >& get_evaluator() const;
	void set_evaluator(const std::shared_ptr<Evaluator<E, G, F> > &evaluator);
	const std::shared_ptr<Fitness<F> >& get_fitness() const;
	void set_fitness(const std::shared_ptr<Fitness<F> > &fitness);
	const std::shared_ptr<Functions<E> >& get_functions() const;
	void set_functions(const std::shared_ptr<Functions<E> > &functions);
	const std::shared_ptr<Mutation<G,F> >& get_mutation() const;
	void set_mutation(const std::shared_ptr<Mutation<G,F> > &mutation);
	const std::shared_ptr<StaticPopulation<G, F> >& get_population() const;
	void set_population(
			const std::shared_ptr<StaticPopulation<G, F> > &population);
	const std::shared_ptr<BlackBoxProblem<E, G, F> >& get_problem() const;
	void set_problem(const std::shared_ptr<BlackBoxProblem<E, G, F> > &problem);
	const std::shared_ptr<Species<G> >& get_species() const;
	void set_species(const std::shared_ptr<Species<G> > &species);
	const std::shared_ptr<Parameters>& get_parameters() const;
	const std::shared_ptr<Random>& get_random() const;
	void set_random(const std::shared_ptr<Random> &random);
};

template<class E, class G, class F>
EvolutionaryComposite<E, G, F>::EvolutionaryComposite(
		std::shared_ptr<Parameters> p_parameters) {

	if (p_parameters != nullptr) {
		parameters = p_parameters;
	} else {
		throw std::invalid_argument("Nullpointer exception in mutation class!");
	}

	init();
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::init() {

	if (this->parameters->is_generate_random_seed()) {
		this->random = std::make_shared<Random>(this->parameters);
	} else {
		long long global_seed = this->parameters->get_global_seed();
		this->random = std::make_shared<Random>(global_seed, this->parameters);
	}

	this->species = std::make_shared<Species<G>>(this->random,
			this->parameters);
	this->population = std::make_shared<StaticPopulation<G, F>>(this->random,
			this->parameters);
	this->mutation = std::make_shared<Mutation<G,F>>(this->parameters,
			this->random, this->species);

	this->mutation_pipeline = std::make_shared<MutationPipeline<G,F>>(this->parameters,
				this->random, this->species);

	F ideal_fitness = this->parameters->get_ideal_fitness();

	this->fitness = std::make_shared<Fitness<F>>(this->parameters,
			ideal_fitness);
	this->fitness->set_minimize(parameters->is_minimizing_fitness());

	this->functions = std::make_shared<FunctionsBoolean<E>>(parameters);
	this->evaluator = std::make_shared<Evaluator<E, G, F>>(this->parameters,
			this->functions, this->species);

}

template<class E, class G, class F>
const std::shared_ptr<Evaluator<E, G, F> >& EvolutionaryComposite<E, G, F>::get_evaluator() const {
	return evaluator;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_evaluator(
		const std::shared_ptr<Evaluator<E, G, F> > &evaluator) {
	this->evaluator = evaluator;
}

template<class E, class G, class F>
const std::shared_ptr<Fitness<F> >& EvolutionaryComposite<E, G, F>::get_fitness() const {
	return this->fitness;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_fitness(
		const std::shared_ptr<Fitness<F> > &fitness) {
	this->fitness = fitness;
}

template<class E, class G, class F>
const std::shared_ptr<Functions<E> >& EvolutionaryComposite<E, G, F>::get_functions() const {
	return functions;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_functions(
		const std::shared_ptr<Functions<E> > &functions) {
	this->functions = functions;
}

template<class E, class G, class F>
const std::shared_ptr<Mutation<G,F> >& EvolutionaryComposite<E, G, F>::get_mutation() const {
	return mutation;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_mutation(
		const std::shared_ptr<Mutation<G,F> > &mutation) {
	this->mutation = mutation;
}

template<class E, class G, class F>
const std::shared_ptr<StaticPopulation<G, F> >& EvolutionaryComposite<E, G, F>::get_population() const {
	return population;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_population(
		const std::shared_ptr<StaticPopulation<G, F> > &population) {
	this->population = population;
}

template<class E, class G, class F>
const std::shared_ptr<BlackBoxProblem<E, G, F> >& EvolutionaryComposite<E, G, F>::get_problem() const {
	return problem;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_problem(
		const std::shared_ptr<BlackBoxProblem<E, G, F> > &problem) {
	this->problem = problem;
}

template<class E, class G, class F>
const std::shared_ptr<Species<G> >& EvolutionaryComposite<E, G, F>::get_species() const {
	return species;
}

template<class E, class G, class F>
const std::shared_ptr<Random>& EvolutionaryComposite<E, G, F>::get_random() const {
	return random;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_random(
		const std::shared_ptr<Random> &random) {
	this->random = random;
}

template<class E, class G, class F>
const std::shared_ptr<Parameters>& EvolutionaryComposite<E, G, F>::get_parameters() const {
	return parameters;
}

template<class E, class G, class F>
void EvolutionaryComposite<E, G, F>::set_species(
		const std::shared_ptr<Species<G> > &species) {
	this->species = species;
}

#endif /* COMPOSITE_EVOLUTIONARYCOMPOSITE_H_ */
