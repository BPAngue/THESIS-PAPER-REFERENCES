/*
 * parameters.h
 *
 *  Created on: 26.04.2020
 *      Author: roman
 */

#ifndef PARAMETERS_PARAMETERS_H_
#define PARAMETERS_PARAMETERS_H_

typedef unsigned int EVAL_METHOD;
typedef unsigned int MUTATION_TYPE;


#include <stdexcept>
#include <iostream>
#include <cassert>
#include <climits>
#include <memory>
#include <vector>

#include "../template_types.h"

class Parameters {
public:
	const EVAL_METHOD FITNESS_EVALUATIONS_TO_TERMINATION = 0;
	const EVAL_METHOD BEST_FITNESS_OF_RUN = 1;

	const MUTATION_TYPE PROBABILISTIC_POINT_MUTATION = 0;
	const MUTATION_TYPE SINGLE_ACTIVE_GENE_MUTATION = 1;
private:

	int genome_size;
	int num_function_nodes;
	int num_inputs;
	int num_outputs;
	int num_functions;
	int num_jobs;
	int max_arity;

	long long max_fitness_evaluations;
	long long max_generations;

	long long global_seed;

	FITNESS_TYPE ideal_fitness;

	float mutation_rate;
	float crossover_rate;

	int population_size;
	int mu;
	int lambda;
	std::shared_ptr<std::vector<MUTATION_TYPE>> mutation_operators;
	MUTATION_TYPE mutation_type;
	int crossover_type;
	int levels_back;
	int num_offspring;
	int num_parents;

	bool neutral_genetic_drift;

	bool evaluate_expression;
	bool minimizing_fitness;
	bool report_during_job;
	bool report_after_job;
	bool report_simple;
	bool print_parameters;
	bool generate_random_seed;

	int report_interval;
	int simple_report_type;

public:
	Parameters();
	virtual ~Parameters() = default;

	void print();

	void set_genome_size();
	int get_genome_size() const;
	void set_genome_size(int p_genome_size);
	int get_max_arity() const;
	void set_max_arity(int p_max_arity);
	int get_num_functions() const;
	void set_num_functions(int p_num_functions);
	int get_num_inputs() const;
	void set_num_inputs(int P_num_inputs);
	int get_num_function_nodes() const;
	void set_num_function_nodes(int p_num_nodes);
	int get_num_outputs() const;
	void set_num_outputs(int p_num_outputs);
	float get_mutation_rate() const;
	void set_mutation_rate(float p_mutation_rate);
	float get_crossover_rate() const;
	void set_crossover_rate(float p_crossover_rate);
	int get_crossover_type() const;
	void set_crossover_type(int p_crossover_type);
	FITNESS_TYPE get_ideal_fitness() const;
	void set_ideal_fitness(FITNESS_TYPE p_ideal_fitness);
	long long get_max_fitness_evaluations() const;
	void set_max_fitness_evaluations(long long p_max_fitness_evaluations);
	long long get_max_generations() const;
	void set_max_generations(long long p_max_generations);
	int get_population_size() const;
	void set_population_size(int p_population_size);
	void set_lambda(int p_lambda);
	int get_lambda() const;
	int get_levels_back() const;
	void set_levels_back(int p_levels_back);
	bool is_minimizing_fitness() const;
	void set_minimizing_fitness(bool p_miniming_fitness);
	int get_num_jobs() const;
	void set_num_jobs(int numJobs);
	int get_report_interval() const;
	void set_report_interval(int p_report_interval);
	bool is_report_during_job() const;
	void set_report_during_job(bool p_report_during_job);
	bool is_report_after_job() const;
	void set_report_after_job(bool p_report_after_job);
	bool is_report_simple() const;
	void set_report_simple(bool p_report_simple);
	int get_simple_report_type() const;
	void set_simple_report_type(int p_simple_report_type);
	bool is_evaluate_expression() const;
	void set_evaluate_expression(bool p_evaluate_expression);
	bool is_neutral_genetic_drift() const;
	void set_neutral_genetic_drift(bool p_neutral_genetic_drift);
	int get_num_offspring() const;
	void set_num_offspring(int p_num_offspring);
	bool is_print_parameters() const;
	void set_print_parameters(bool p_print_parameters);
	int get_num_parents() const;
	void set_num_parents(int p_num_parents);
	long long get_global_seed() const;
	void set_global_seed(long long globalSeed);
	const std::shared_ptr<std::vector<MUTATION_TYPE> >& get_mutation_operators() const;
	void set_mutation_operators(
			const std::shared_ptr<std::vector<MUTATION_TYPE> > &p_mutation_operators);
	MUTATION_TYPE get_mutation_type() const;
	void set_mutation_type(MUTATION_TYPE p_mutation_type);
	bool is_generate_random_seed() const;
	void set_generate_random_seed(bool generateRandomSeed);
};


#endif /* PARAMETERS_PARAMETERS_H_ */
