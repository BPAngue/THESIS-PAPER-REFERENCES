#include <string>
#include <memory>
#include <unistd.h>
#include <iostream>
#include <getopt.h>
#include <fstream>
#include <string>
#include <filesystem>

#include "template_types.h"
#include "evolver/Evolver.h"

void usage(const char *self) {
	std::cout << "usage: %s PLUfile <options>" << self << std::endl;
	std::cout << "-n <value>          number of function nodes" << std::endl;
	std::cout << "-i <value>          number of inputs" << std::endl;
	std::cout << "-o <value>          number of outputs" << std::endl;
	std::cout << "-f <value>          number of functions" << std::endl;
	std::cout << "-a <value>          maximum arity" << std::endl;
	std::cout << "-m <value>          mutation rate" << std::endl;
	std::cout << "-p <value>          number of parents" << std::endl;
	std::cout << "-c <value>          number of children" << std::endl;
	std::cout << "-e <value>          maximal number of fitness evaluations"
			<< std::endl;
	std::cout << "-g <value>          goal (ideal) fitness" << std::endl;
	std::cout << "-j <value>          number of jobs" << std::endl;
	std::cout << "-s <value>          global seed" << std::endl;
	exit(1);
}

int main(int argcc, char **argvv, char **envp) {

	if (argcc < 3)
		usage(*argvv);

	std::string plu_file = argvv[1];
	std::string param_file = argvv[2];

	int num_nodes = -1;
	int num_inputs = -1;
	int num_outputs = -1;
	float mutation_rate = -1;
	int num_parents = -1;
	int num_offspring = -1;
	int num_jobs = -1;
	int num_functions = -1;
	int max_arity = -1;
	long long max_fitness_evaluations = -1;
	long long global_seed = -1;

	FITNESS_TYPE ideal_fitness = -1;

	char opt;
	while ((opt = getopt(argcc, argvv, "n:i:o:f:a:m:p:c:e:g:j:s:")) != -1) {
		switch (opt) {

		case 'n':
			num_nodes = atoi(optarg);
			break;

		case 'i':
			num_inputs = atoi(optarg);
			break;

		case 'o':
			num_outputs = atoi(optarg);
			break;

		case 'f':
			num_functions = atoi(optarg);
			break;

		case 'a':
			max_arity = atoi(optarg);
			break;

		case 'm':
			mutation_rate = atof(optarg);
			break;

		case 'p':
			num_parents = atoi(optarg);
			break;

		case 'c':
			num_offspring = atoi(optarg);
			break;

		case 'e':
			max_fitness_evaluations = atol(optarg);
			break;

		case 'g':
			ideal_fitness = atoi(optarg);
			break;

		case 'j':
			num_jobs = atoi(optarg);
			break;

		case 's':
			global_seed = atol(optarg);
			break;

		default:
			usage(*argvv);
			exit(1);
		}

	}

	std::shared_ptr<
			BooleanFunctionInitializer<EVALUATION_TYPE, GENOME_TYPE,
					FITNESS_TYPE>> initializer = std::make_shared<
			BooleanFunctionInitializer<EVALUATION_TYPE, GENOME_TYPE,
					FITNESS_TYPE>>(plu_file);

	initializer->init_comandline_parameters(num_nodes, num_inputs,
			num_outputs, num_functions, max_arity, num_parents, num_offspring,
			mutation_rate, max_fitness_evaluations, ideal_fitness, num_jobs, global_seed);

	initializer->init_parfile_parameters(param_file);

	initializer->read_data();
	initializer->init_evolutionary_composite();
	initializer->init_problem();
	initializer->init_algorithm();

	std::shared_ptr<Evolver<EVALUATION_TYPE, GENOME_TYPE, FITNESS_TYPE>> evolver =
			std::make_shared<Evolver<EVALUATION_TYPE, GENOME_TYPE, FITNESS_TYPE>>(
					initializer);

	evolver->run();

}
