/*
 * Recombination.h
 *
 *  Created on: 08.07.2021
 *      Author: roman
 */

#ifndef RECOMBINATION_RECOMBINATION_H_
#define RECOMBINATION_RECOMBINATION_H_

#include "../parameters/Parameters.h"

#include <stdexcept>

class Recombination {
private:
	float crossover_rate;
	int crossover_type;
	void subgraph(int parent1[], int  parent2[]);
	void block(int  parent1[], int  parent2[]);
	void discrete(int  parent1[], int  parent2[]);
public:
	Recombination(Parameters *parameters);
	virtual ~Recombination() = default;
	void recombination(int genome[]);
};

#endif /* RECOMBINATION_RECOMBINATION_H_ */
