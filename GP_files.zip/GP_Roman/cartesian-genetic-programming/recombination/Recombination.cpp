/*
 * Recombination.cpp
 *
 *  Created on: 08.07.2021
 *      Author: roman
 */

#include "Recombination.h"

Recombination::Recombination(Parameters *p_parameters) {

	if (p_parameters != nullptr) {

		} else {
			throw std::invalid_argument(
					"Nullpointer exception in mutation class!");
		}
}

